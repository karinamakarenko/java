package point;
import java.util.Scanner;
public class Point {
    private int x, y;
    public Point()throws NumberFormatException
    {
        try{
        Scanner in = new Scanner(System.in);
        System.out.println("Введите начальные координаты: ");
        x = in.nextInt();
        y = in.nextInt();
        }
        catch(Exception e)
        {
            System.out.println("Неверные данные!");
            System.exit(0);
        }
    }
    public Point(int init_x, int init_y)
    {
        x = init_x;
        y = init_y;
    }
    public Point(Point point)
    {
        this.x = point.x;
        this.y = point.y;
    }
    public int getХ()
    {
        return x;
    }
    public void setХ(int newX)
    {
        x = newX;
    }
    public int getY()
    {
        return y;
    }
    public void setY(int newY)
    {
        y = newY;
    }
    public void moveX(int addX)
    {
        x = x + addX;
    }
    public void moveY(int addY)
    {
        y += addY;
    }
    public void output()
    {
       // System.out.println(toString());
        System.out.println(this);
    }
    public double dist1()
    {
        return Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    }
    public double dist2(Point p2)
    {
        return Math.sqrt(Math.pow((p2.getY() - y), 2) + Math.pow((p2.getХ() - x),2));
    }
    //аннотация
    @Override
    public String toString()
    {
        return "("+x+";"+y+")";
    }
    public boolean equalsPoint(Point p)
    {
        if(this.x == p.x && this.y == p.y)
        {
        return true;
        }
        return false;
    }
}