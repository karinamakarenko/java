package point;
import java.util.Scanner;
public class TestPoint {
    public static void main(String[] args)
    {
        try
        {
        Scanner in = new Scanner(System.in);
        Point p1;
        Point p2;
        p1 = new Point();
        System.out.println("Координаты точки 1: ");
        p1.output();
        int x = 5;
        p1.setХ(x);
        System.out.println("координата X = " + p1.getХ());
        p1.output();
        p2 = new Point(7,12);
        System.out.println("Координаты точки 2: ");
        p2.output();
        Point p3;
        p3 = new Point(p1);
        System.out.println("Координаты точки 3: ");
        p3.output();
        p2.setY(8);
        System.out.println("координата Y = " + p2.getY());
        x = 9;
        int y = 5;
        p2.moveX(x);
        p2.moveY(y);
        System.out.println("После перемещения точка 2: ");
        p2.output();
        System.out.println("Точки 1 и 2 совпадают? " + p1.equalsPoint(p2));
        System.out.println("Расстояние от заданной точки до начала координат: " + p1.dist1());
        System.out.println("Расстояние от заданной точки до начала координат: " + p2.dist1());
        System.out.println("Расстояние от 1 точки до 2: " + p1.dist2(p2));
        }
        catch(Exception e)
        {
            System.out.println("Введены некорректные данные. Попробуйте ещё раз!");
        }
    }
}
